#include "typedef.h"
/*
class CTrapezium {
      static CBoard &board;
      short  x,y;
      unsigned char color, direction;
public:
      CTrapezium(short x_, short y_, char color_, unsigned char direction_);
      int  mvDown();
      int  mvLeft();
      int  mvRight(); 
      int  rotateLeft();
      int  rotateRight();
};
*/
CTrapezium::CTrapezium(short x_, short y_, char color_, unsigned char direction_){
     short xTriangle, yTriangle;
     unsigned short triangle;
     POINT position;
     
     
     color = color_ % (COLOR_NUM+1);
     direction = direction_;
     
     switch ( direction_ ) {
            case HUTRAPEZIUM:
            case HDTRAPEZIUM:
                 if ( x_<2 || x_>10 ) x = 6;
                 else x = x_;
                 if ( y_>30 || y_<1 ) y = 30;
                 else y = y_;
                 break;
            case VRTRAPEZIUM:
            case VLTRAPEZIUM:
                 if ( x_<1 || x_>11 ) x = 6;
                 else x = x_;
                 if ( y_>29 || y_<2 ) y = 29;
                 else y = y_;
                 break;
            default:
                 x=0;
                 y=0;
                 color = 0;
                 direction = 0;
                 break;
     }
     show();
     return;
}

void CTrapezium::erase() {
     board.resetState(x, y, LUTRIANGLE);
     board.resetState(x, y, RDTRIANGLE);
     switch ( direction ) {
            case HUTRAPEZIUM:
                 board.resetState(x-1, y, RDTRIANGLE);
                 board.resetState(x+1, y, LDTRIANGLE);
                 break;
            case VRTRAPEZIUM:
                 board.resetState(x, y+1, LDTRIANGLE);
                 board.resetState(x, y-1, LUTRIANGLE);
                 break;
            case HDTRAPEZIUM:
                 board.resetState(x-1, y, RUTRIANGLE);
                 board.resetState(x+1, y, LUTRIANGLE);
                 break;
            case VLTRAPEZIUM:
                 board.resetState(x, y+1, RDTRIANGLE);
                 board.resetState(x, y-1, RUTRIANGLE);
                 break;
            default:
                 break;
     } 
     
     return;
}

void CTrapezium::show() {
     unsigned short triangle = color<<4;
     
     switch ( direction ) {
            case HUTRAPEZIUM:
                 triangle = (triangle&0xF0)|RDTRIANGLE;
                 board.setState(x-1, y, triangle);
                 triangle = (triangle&0xF0)|LDTRIANGLE;
                 board.setState(x+1, y, triangle);
                 break;
            case HDTRAPEZIUM:
                 triangle = (triangle&0xF0)|RUTRIANGLE;
                 board.setState(x-1, y, triangle);
                 triangle = (triangle&0xF0)|LUTRIANGLE;
                 board.setState(x+1, y, triangle);
                 break;
            case VRTRAPEZIUM:
                 triangle = (triangle&0xF0)|LDTRIANGLE;
                 board.setState(x, y+1, triangle);
                 triangle = (triangle&0xF0)|LUTRIANGLE;
                 board.setState(x, y-1, triangle);
                 break;
            case VLTRAPEZIUM:
                 triangle = (triangle&0xF0)|RDTRIANGLE;
                 board.setState(x, y+1, triangle);
                 triangle = (triangle&0xF0)|RUTRIANGLE;
                 board.setState(x, y-1, triangle);
                 break;
            default:
                 break;
     }
     triangle = (triangle&0xF0)|LUTRIANGLE;
     board.setState(x, y, triangle);
     triangle = (triangle&0xF0)|RDTRIANGLE;
     board.setState(x, y, triangle);       
     return;
}

int CTrapezium::mvDown(){
     bool  stopped;
     unsigned short triangle = color<<4;

     switch ( direction ) {
            case HUTRAPEZIUM:
                 stopped = board.getRim(x,y-1)|board.getRim(x-1,y-1)|board.getRim(x+1,y-1);
                 break;
            case VRTRAPEZIUM:
                 stopped = (board.getRim(x,y-1)&RDTRIANGLE)|(board.getRim(x,y-2)&LUTRIANGLE);
                 break;
            case HDTRAPEZIUM:
                 stopped = (board.getRim(x-1,y)&LDTRIANGLE)|board.getRim(x,y-1);
                 stopped = stopped || (board.getRim(x+1,y)&RDTRIANGLE);
                 stopped = stopped || (board.getRim(x-1,y-1)&RUTRIANGLE);
                 stopped = stopped || (board.getRim(x+1,y-1)&LUTRIANGLE);
                 break;
            case VLTRAPEZIUM:
                 stopped = (board.getRim(x,y-1)&LDTRIANGLE)|(board.getRim(x,y-2)&RUTRIANGLE);
                 break;
            default:
                 return UNDEFINED;
     } 
     if ( stopped ) return STOPPED;
     erase();
     y--;
     show();
     
     return MV_DOWN;
}

int CTrapezium::mvLeft(){
     return MV_LEFT;

}

int CTrapezium::mvRight(){
     return MV_RIGHT;
}
int CTrapezium::rotateLeft(){
     bool  stopped=true;
     char lPixel, rPixel;
     
     switch ( direction ) {
            case HUTRAPEZIUM:
                 if ( board.getRim(x-1,y-1) ) break;
                 if ( board.getRim(x,y-1)) break;
                 if ( board.getRim(x+1, y+1) ) break;
                 if ( board.getRim(x+1,y)&RUTRIANGLE) break;
                 if ( board.getRim(x,y+1)&RDTRIANGLE ) break;
                 stopped = false;
                 break;
            case VRTRAPEZIUM:
                 if ( board.getRim(x-1,y+1) ) break;
                 if ( board.getRim(x-1,y)) break;
                 if ( board.getRim(x, y-1)&RDTRIANGLE ) break;
                 if ( board.getRim(x+1,y-1)) break;
                 if ( board.getRim(x+1,y)&LDTRIANGLE ) break;
                 stopped = false;
                 break;
            case HDTRAPEZIUM:
                 if ( board.getRim(x+1,y+1) ) break;
                 if ( board.getRim(x,y+1)) break;
                 if ( board.getRim(x-1, y)&LDTRIANGLE ) break;
                 if ( board.getRim(x-1,y-1)) break;
                 if ( board.getRim(x,y-1)&LUTRIANGLE ) break;
                 stopped = false;
                 break;
            case VLTRAPEZIUM:
                 if ( board.getRim(x+1,y-1) ) break;
                 if ( board.getRim(x+1,y)) break;
                 if ( board.getRim(x, y+1)&LUTRIANGLE ) break;
                 if ( board.getRim(x-1,y+1)) break;
                 if ( board.getRim(x-1,y)&RUTRIANGLE ) break;
                 stopped = false;
                 break;
            default:
                 return UNDEFINED;
     } 
     if ( stopped ) return mvDown();
     erase();
     lPixel = direction>>4;
     rPixel = direction&0xF;
     rPixel = ((rPixel&7)<<1)|(rPixel>>3);
     lPixel = ((lPixel&7)<<1)|(lPixel>>3);
     direction = (rPixel<<4)|lPixel;
     show();
     return RT_LEFT;
}

int CTrapezium::rotateRight(){
     return RT_RIGHT;
}
