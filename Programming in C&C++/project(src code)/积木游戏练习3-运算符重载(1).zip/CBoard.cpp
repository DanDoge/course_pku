#include "typedef.h"
/*
class CBoard {
      CDisplay* pDisplay;
      unsigned short pixels[31][13];  
public:
       CBoard();
       CBoard(unsigned short boardState[]);
       bool init(CDisplay* pDisplay_);
       unsigned short  getRim(short x, short y);
       unsigned short  getState(short x, short y);
       bool setState(short x, short y, unsigned short triangle);
       bool resetState(short x, short y, unsigned short triangle);
};
*/
CBoard::CBoard() {
      int i;
      for( i=0; i<13; i++ ) pixels[0][i] = UNDEFINED;
      for( i=1; i<31; i++ ) pixels[i][0] = pixels[i][12] = UNDEFINED;
      for( int i=0; i<30; i++ )
          for( int j=0; j<11; j++) pixels[i+1][j+1]=0;
      pDisplay = NULL;

}

CBoard::CBoard(unsigned short boardState[]) {
      int i, j;
      for( i=0; i<13; i++ ) pixels[0][i] = UNDEFINED;
      for( i=1; i<31; i++ ) pixels[i][0] = pixels[i][12] = UNDEFINED;
      for( i=0; i<30; i++ )
          for( j=0; j<11; j++) pixels[i+1][j+1]=boardState[i*11+j];
      pDisplay = NULL;
               
}
bool CBoard::init(CDisplay* pDisplay_) {
     if ( pDisplay != NULL ) return false;
     pDisplay = pDisplay_;
     return true;
}

void CBoard::repaint() {
     int i, j;
     
     for(i=1; i<=30; i++) 
         for(j=1; j<=11; j++){
			pDisplay->show(j, i, pixels[i][j]);
			pDisplay->show(j, i, pixels[i][j]>>8);
		}
     //pDisplay->show(rowStates);
     
     return;
}

unsigned short CBoard::getState(short x, short y) {
     if ( x<1 || x>11 || y<1 || y>30 ) return UNDEFINED;
     return  pixels[y][x];
}
unsigned short CBoard::getRim(short x, short y) {
     if ( x<1 || x>11 || y<1 || y>30 ) return UNDEFINED; 
     return ((pixels[y][x]>>8)|pixels[y][x])&0xF;
}
/*
bool CBoard::setState(short x, short y, unsigned short triangle) {
     if ( x<1 || x>11 || y<1 || y>30 ) return false;
     if ( (pixels[y][x]&0xF) == (triangle&0xF) ) return false;
     switch (((pixels[y][x]>>8)|pixels[y][x])&0xF) {
            case 0xF:
                 return false;
            case 0:
                 pixels[y][x] = triangle;
                 break;
            default:
                 if ((triangle|pixels[y][x])&0xF!=0xF) return false;
                 pixels[y][x] = (triangle<<8)|pixels[y][x];
                 break;
     }
     if (pDisplay==NULL) return false;
     pDisplay->show(x, y, triangle);
     return true;
}

bool CBoard::resetState(short x, short y, unsigned short triangle) {
     if ( x<1 || x>11 || y<1 || y>30 ) return false;
     if ( (triangle&0xF)== (pixels[y][x]&0xF) ) {
          pDisplay->erase(x, y, triangle);
          pixels[y][x]=pixels[y][x]>>8;          
          return true;
     }
     if ( (triangle&0xF)== ((pixels[y][x]>>8)&0xF) ) {
          pDisplay->erase(x, y, triangle);
          pixels[y][x]=pixels[y][x]&0xFF;
          return true;
     }
     
     return false;
}
*/
CBoard& CBoard::operator<<(CTriangle triangle) {
     int x=triangle.x;
     int y=triangle.y;
     unsigned char color = triangle.color;
     unsigned char direction = triangle.direction;
     
     if ( x<1 || x>11 || y<1 || y>30 ) return (*this);
     switch (((pixels[y][x]>>8)|pixels[y][x])&0xF) {
            case 0xF:
                 return (*this);
            case 0:
                 pixels[y][x] = (color<<4)|direction;
                 break;
            default:
                 if (direction&pixels[y][x]&0xF) return (*this);
                 pixels[y][x] = ((color<<4)|direction)|(pixels[y][x]<<8);
                 break;
     }
     if (pDisplay==NULL) return (*this);
     pDisplay->show(x, y, (color<<4)|direction);
     return (*this);      
}

