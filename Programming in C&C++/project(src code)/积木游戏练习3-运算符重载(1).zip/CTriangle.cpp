#include "typedef.h"
/*
class CTriangle {
      short  x,y;
      unsigned char color, direction;
friend class CBoard;
public:
      CTriangle(short x_, short y_, char color_, unsigned char direction_);
};
*/
CTriangle::CTriangle(short x_, short y_, char color_, unsigned char direction_) {
     x = x_;
     y = y_;
     color = color_ % (COLOR_NUM+1);
     direction = direction_;
     if ( x_<1 || x_>11 ) x = 6;
     if ( y_>30 || y_<1 ) y = 30;
     switch ( direction_ ) {
            case LUTRIANGLE:
            case RUTRIANGLE:
            case RDTRIANGLE:
            case LDTRIANGLE:
                 break;
            default:
                 x=0;
                 y=0;
                 color = 0;
                 direction = 0;
                 break;
     }
          
     return;
}

