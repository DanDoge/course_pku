#include "typedef.h"
/*
class CPlayer {
      CDisplay* pDisplay;
      CBoard&   board;
      const static unsigned char brickType[SHAPE_NUM];
      HWND hWnd; //main window
      UINT_PTR hTimer;
      int  command;
      unsigned short curBrickType;
      CTrapezium* pTrapezium;
      bool newBrick();
      void newGame();
public:
       CPlayer(CBoard& board_);
       bool clickButton(LPARAM hButton);
       void init(HWND hWnd_);
       void executeCommand();
       ~CPlayer();
};
*/

CPlayer::CPlayer(CBoard& board_):board(board_) {
      hTimer = 0;
      pDisplay = NULL;
      curBrickType = UNDEFINED;
      pTrapezium = NULL;
      command = UNDEFINED;
      return; 
}

void CPlayer::init(HWND hWnd_) {
     hWnd = hWnd_;     
     pDisplay = new CDisplay(hWnd_);
     board.init(pDisplay);
     return; 
}

void CPlayer::repaint() {
     
     pDisplay->refresh();
     board.repaint();     
     return; 
}

void CPlayer::newGame() {
     newBrick();
     hTimer = SetTimer(hWnd, TIMER_ID, MV_SPEED, NULL);
     
     return;      
}

void CPlayer::executeCommand() {
     short result;
     RECT  rcClient;
     HDC hDC;
     if (pTrapezium==NULL) return;
     switch ( command ) {
     case MV_LEFT:
          result = pTrapezium->mvLeft();
          break;
     case MV_RIGHT:
          result = pTrapezium->mvRight();
          break;
     case RT_LEFT:
          result = pTrapezium->rotateLeft();
          break;
     case RT_RIGHT:
          result = pTrapezium->rotateRight();
          break;
     default:
          result = pTrapezium->mvDown();
          break;     
     }
     if (command == MV_DOWN) while(result!=STOPPED) result = pTrapezium->mvDown();
     command = UNDEFINED;
     if ( result==STOPPED ) {
          delete pTrapezium;
          pTrapezium = NULL;
          result=newBrick();
     }
     return;
}

CPlayer::~CPlayer() {
      if ( hTimer!=0 ) KillTimer(hWnd, TIMER_ID);
      if (pDisplay != NULL) delete pDisplay;
      
      if (curBrickType==UNDEFINED) return;
      switch ( brickType[curBrickType] ) {
      case SQUARE:
      case HRECTANGLE:
      case VRECTANGLE:
      case LUTRIANGLE:
      case RUTRIANGLE:
      case RDTRIANGLE:
      case LDTRIANGLE:
           break;
      case HUTRAPEZIUM:
      case VRTRAPEZIUM:
      case HDTRAPEZIUM:
      case VLTRAPEZIUM:
           delete pTrapezium;
           break;
      default:
              break;
      }
      return; 
}

bool CPlayer::newBrick() {
     int color = rand()%COLOR_NUM + 1;
          
     if ( board.getRim(6, 30)&LUTRIANGLE&RUTRIANGLE ) return false;
     //curBrickType = rand()%SHAPE_NUM;
     curBrickType = rand()%4+7;
     switch ( brickType[curBrickType] ) {
     case SQUARE:
     case HRECTANGLE:
     case VRECTANGLE:
     case LUTRIANGLE:
     case RUTRIANGLE:
     case RDTRIANGLE:
     case LDTRIANGLE:
          break;
     case HUTRAPEZIUM:
     case HDTRAPEZIUM:
          if ( board.getRim(5, 30)|| board.getRim(6, 30)||board.getRim(7, 30)) return newBrick();
          if (pTrapezium != NULL) delete pTrapezium;
          pTrapezium = new CTrapezium(6, 30, color, brickType[curBrickType]);
          break;
     case VRTRAPEZIUM:
     case VLTRAPEZIUM:
          if ( board.getRim(6, 30)||board.getRim(6, 29)|| board.getRim(6, 28)) return newBrick();
          if (pTrapezium != NULL) delete pTrapezium;
          pTrapezium = new CTrapezium(6, 29, color, brickType[curBrickType]);
          break;
     default:
           break;
     }    
     return true;
}

bool CPlayer::clickButton(LPARAM hButton) {
     
     command = pDisplay->parseCommand(hButton);
     switch ( command ) {
            case NEW_GAME:
                 newGame();
                 break;
            case EXIT_GAME:
                 return false;
            default:
                    break;
     }
     
     return true;
}
