#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <stdlib.h>

#define EMPTY      0x0000
#define UNDEFINED  0xFFFF
#define STOPPED    0
#define MV_DOWN    1
#define MV_RIGHT   2
#define MV_LEFT    3
#define RT_RIGHT   4
#define RT_LEFT    5
#define NEW_GAME   10
#define OPEN_GAME  11
#define SAVE_GAME  12
#define EXIT_GAME  13
#define SQUARE     0x0F     //square: 0000 1111  
#define HRECTANGLE 0xAA     //horizonal rectangle: 1010 1010
#define VRECTANGLE 0x55     //vertical rectangle: 0101 0101
#define LUTRIANGLE 0x0C     //triangle on the left-up conner: 0000 1100
#define RUTRIANGLE 0x06     //triangle on the right-up conner: 0000 0110
#define RDTRIANGLE 0x03     //triangle on the right-down conner: 0000 0011
#define LDTRIANGLE 0x09     //triangle on the left-down conner: 0000 1001
#define HUTRAPEZIUM 0x39    //horizonal trapezium shrinking up: 0011 1001
#define VRTRAPEZIUM 0xC9    //vertical trapezium shrinking right: 1100 1001
#define HDTRAPEZIUM 0xC6    //horizonal trapezium shrinking down: 1100 0110
#define VLTRAPEZIUM 0x36    //vertical trapezium shrinking left: 0011 0110

#define BUTTON_HEIGHT 35
#define BUTTON_WIDTH 100
#define BUTTON_SPACE 10

#define COLOR_NUM 5
#define SHAPE_NUM 11
#define TIMER_ID  1000
#define MV_SPEED  500

class CTriangle;
class CTrapezium;
struct SRowState {
       int blankTriangles;
       bool linked;
};
class CDisplay {
      HWND hWnd,
           hBnNew, //child-windown for new-button
           hBnSave, //child-windown for save-button
           hBnOpen, //child-windown for open-button           
           hBnExit, //child-windown for exit-button           
           hBnMvLeft, //child-windown for mvLeft-button
           hBnMvRight, //child-windown for mvRight-button
           hBnMvDown, //child-windown for mvDown-button
           hBnRtClck, //child-windown for rotate-clockwise-button
           hBnRtAntiClck;//child-windown for rotate-anti-clockwise-button

      HDC  hDC;
      COLORREF colorRef[COLOR_NUM+7];      
      RECT  boardRect, scoreRect;
      int   winWidth, winHeight, boardLegend;
      bool fillTriangle(int color, int x, int y, int triangle) const;
public:
       CDisplay(HWND hWnd_);
       ~CDisplay();
       void refresh();
       int  parseCommand(LPARAM hButton) const;
       bool show(int x, int y, int triangle) const;
       bool erase(int x, int y, int triangle) const;
       void show(int arg) const; 
       void show(char arg[])const; 
       //void show(SRowState arg[]) const; 
       void show(CTrapezium& arg) const;
};

class CBoard {
      CDisplay* pDisplay;
      unsigned short pixels[31][13]; 
public:
       CBoard();
       CBoard(unsigned short boardState[]);
       bool init(CDisplay* pDisplay_);
       unsigned short  getRim(short x, short y);
       unsigned short  getState(short x, short y);
       void repaint();
       //bool setState(short x, short y, unsigned short triangle);
       //bool resetState(short x, short y, unsigned short triangle);
       CBoard& operator<<(CTriangle triangle);
};

class CTrapezium {
      static CBoard &board;
      short  x,y;
      unsigned char color, direction;
      void show();
      void erase();
public:
      CTrapezium(short x_, short y_, char color_, unsigned char direction_);
      int  mvDown();
      int  mvLeft();
      int  mvRight(); 
      int  rotateLeft();
      int  rotateRight();
friend class CDisplay;
};

class CPlayer {
      CDisplay* pDisplay;
      CBoard&   board;
      const static unsigned char brickType[SHAPE_NUM];
      HWND hWnd; //main window
      UINT_PTR hTimer;
      int  command;
      unsigned short curBrickType;
      CTrapezium* pTrapezium;
      bool newBrick();
      void newGame();
public:
       CPlayer(CBoard& board_);
       void repaint();
       bool clickButton(LPARAM hButton);
       void init(HWND hWnd_);
       void executeCommand();
       ~CPlayer();
};

class CTriangle {
      short  x,y;
      unsigned char color, direction;
friend class CBoard;
public:
      CTriangle(short x_, short y_, char color_, unsigned char direction_);
};
